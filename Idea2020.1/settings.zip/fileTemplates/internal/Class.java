#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")

/**
* @program: ${PROJECT_NAME}
*
* @description: ${description}
*
* @author: pmz 
*
* @create: ${YEAR}-${MONTH}-${DAY} ${HOUR}:${MINUTE}
**/

public class ${NAME} {
}
