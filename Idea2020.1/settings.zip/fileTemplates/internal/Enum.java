#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("File Header.java")
/**
* @desc TODO
* @Author ${USER}
* @Date ${DATE} ${TIME}
* @Version 1.0
*/
public enum ${NAME} {
}
